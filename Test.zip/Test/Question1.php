<?php

    $a = '55';
    echo $a;
echo "+";
    $b = '65';
    echo $b;
echo "+";
    $c = '75';
    echo $c;
echo "=";
 
    echo $a + $b + $c;

